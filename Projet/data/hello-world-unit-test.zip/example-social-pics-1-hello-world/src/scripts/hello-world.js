let helloWorld = {
  init() {
    return 'hello world';
  }
};

export default helloWorld;
